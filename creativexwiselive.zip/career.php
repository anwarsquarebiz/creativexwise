<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Creative X Wise</title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200;300;400;500;600;700&display=swap"
        rel="stylesheet">
</head>

<body>
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light ">
            <a class="navbar-brand" href="/">
                <img src="/assets/images/only Logo.webp" alt="">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="/">HOME</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="whoweare.html" id="navbarScrollingDropdown"
                            role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            WHO WE ARE
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarScrollingDropdown">
                            <li><a class="dropdown-item" href="#">ABOUT US</a></li>
                            <li><a class="dropdown-item" href="#">PEOPLE</a></li>
                            <li><a class="dropdown-item" href="#">CLIENTS</a></li>
                            <li><a class="dropdown-item" href="#">AWARDS AND RECOGNITIONS</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="whatwedo.html">WHAT WE DO</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="terms&condition.html">TERMS & CONDITIONS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#">CAREERS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">CONTACT US</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">CHECKOUT PAGE</a>
                    </li>

                </ul>
            </div>

        </nav>
    </div>

    <div>
        <img src="/assets/images/career.png" alt="" style="width: 1582px; height: 293px; object-fit:cover;">
    </div>

    <div>
        <h1 class="header"
            style="font-family: 'Proxima N W01 Reg'; font-size: 32px; color: #E0266A; font-weight: bold; margin-left: 100px; margin-right: 200px; margin-top: 20px;">
            Careers
        </h1>
    </div>

    <div class="options">
        <p style="margin-left: 90px;">Latest Job Openings</p>
        <p>10 Reasons To Join</p>
        <p>Values</p>
        <p></p>
    </div>

    <div>
        <h1 class="header"
            style="font-family: 'Proxima N W01 Reg'; font-size: 30px; color: #E0266A; font-weight: bold; margin-left: 100px; margin-right: 200px; margin-top: 100px;">
            Latest Job Openings
        </h1>

        <h2
            style="font-family: 'Proxima N W01 Reg'; font-size: 22px; color: black; margin-top: 50px; margin-left: 400px;">
            No Current Openings
        </h2>
    </div>

    <div>
        <h1 class="header"
            style="font-family: 'Proxima N W01 Reg'; font-size: 30px; color: #E0266A; font-weight: bold; margin-left: 100px; margin-right: 200px; margin-top: 50px;">
            10 Reasons To Join
        </h1>
    </div>

    <div style="margin-top: 50px;">
        <img src="/assets/images/10-Reason.png" alt="">
    </div>

    <div class="container" style="margin-top: 100px; margin-left: -50px;">
        <div class="row">
            <img src="/assets/images/cartoon.png" alt="">
            <div class="col-2" style="margin-left: 30px; text-align: center; font-family: proxima-n-w01-reg,proxima-n-w05-reg,sans-serif; font-size: 17px;">
                Our visionary outlook, talent and commitment means we are able to meet any challenge and succeed
            </div>
            <div class="col-2" style="margin-left: 30px; text-align: center; font-family: proxima-n-w01-reg,proxima-n-w05-reg,sans-serif; font-size: 17px;">
                We share a full-blooded passion for our work which means we will always go the extra mile in the pursuit
                of excellence
            </div>
            <div class="col-2" style="margin-left: 30px; text-align: center; font-family: proxima-n-w01-reg,proxima-n-w05-reg,sans-serif; font-size: 17px;">
                Our people share a sense of adventure and a thirst for knowledge. We listen, question and use our
                insight to make good ideas even better
            </div>
            <div class="col-2" style="margin-left: 30px; text-align: center; font-family: proxima-n-w01-reg,proxima-n-w05-reg,sans-serif; font-size: 17px;">
                Our hunger for creative and commercial success means that we constantly strive for improvement
            </div>
            <div class="col-2" style="margin-left: 30px; text-align: center; font-family: proxima-n-w01-reg,proxima-n-w05-reg,sans-serif; font-size: 17px;">
                We are family from different backgrounds and experiences that share a common purpose and goal
            </div>

        </div>
    </div>
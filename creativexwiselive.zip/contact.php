<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Creative X Wise</title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200;300;400;500;600;700&display=swap"
        rel="stylesheet">
</head>

<body>
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light ">
            <a class="navbar-brand" href="/">
                <img src="/assets/images/only Logo.webp" alt="">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="/">HOME</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarScrollingDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            WHO WE ARE
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarScrollingDropdown">
                            <li><a class="dropdown-item" href="#">ABOUT US</a></li>
                            <li><a class="dropdown-item" href="#">PEOPLE</a></li>
                            <li><a class="dropdown-item" href="#">CLIENTS</a></li>
                            <li><a class="dropdown-item" href="#">AWARDS AND RECOGNITIONS</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">WHAT WE DO</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">TERMS & CONDITIONS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">CAREERS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#">CONTACT US</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">CHECKOUT PAGE</a>
                    </li>

                </ul>
            </div>

        </nav>
    </div>

    <div>
        <img src="" alt="">
    </div>

    <div class="container home-maps">

        <h1 class="header"
            style="font-weight:bold; font-family: 'Proxima N W01 Reg'; font-size: 30px; color: #E0266A; margin-left:px; margin-right: px; margin-top: 50px;">
            Contact Us
        </h1>

        <div class="row mb-5">
            <div class="col-lg-4 col-sm-12 mt-5">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3769.092340360366!2d72.83081061525708!3d19.14743485469803!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x16cda2724e6ca377!2zMTnCsDA4JzUwLjgiTiA3MsKwNDknNTguOCJF!5e0!3m2!1sen!2sin!4v1671448427231!5m2!1sen!2sin"
                    width="300" height="300" style="border:0;" allowfullscreen="" loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"></iframe>

                <div>
                    <h1
                        style="font-weight:bold; font-family: 'Proxima N W01 Reg'; font-size: 30px; color: #E0266A; margin-top: 100px;">
                        Mumbai (India)
                    </h1>

                    <h2 style="font-weight:bold; font-family: 'Proxima N W01 Reg'; font-size: 20px;">
                        Creativewise Entertainment Pvt Ltd <br>
                        (Film & Advertising, Broadcast, DI & Equipment Rental)
                    </h2>

                    <h3 style="color: black; font-family: 'Proxima N W01 Reg'; font-size: 20px;">
                        401/B-wing Annapurna Bldg Adarsh Nagar Oshiwara New Link Road

                        Andheri West Mumbai-400053
                    </h3>

                    <h4 style="color: black; font-family: 'Proxima N W01 Reg'; font-size: 20px;">
                        Tel: 022-26310563 <br> E-mail: minfo@creativexwise.com
                    </h4>

                </div>
            </div>
            <div class="col-lg-4 col-sm-12 mt-5">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2830.697527994884!2d-106.95527808425858!3d44.807352579098705!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xab9bb818f8b3d1ab!2zNDTCsDQ4JzI2LjUiTiAxMDbCsDU3JzExLjEiVw!5e0!3m2!1sen!2sin!4v1671545866269!5m2!1sen!2sin"
                    width="300" height="300" style="border:0;" allowfullscreen="" loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"></iframe>

                <div>
                    <h1
                        style="font-weight:bold; font-family: 'Proxima N W01 Reg'; font-size: 30px; color: #E0266A; margin-top: 100px;">
                        Mumbai (India)
                    </h1>

                    <h2 style="font-weight:bold; font-family: 'Proxima N W01 Reg'; font-size: 20px;">
                        Creativewise Entertainment Pvt Ltd <br>
                        (Film & Advertising, DI & VFX)
                    </h2>

                    <h3 style="color: black; font-family: 'Proxima N W01 Reg'; font-size: 20px;">
                        601/C-Wing Remi Bizcourt Bld Off

                        Veera Desai Rd Andheri West Mumbai -400053
                    </h3>

                    <h4 style="color: black; font-family: 'Proxima N W01 Reg'; font-size: 20px;">
                        Tel: +91 9022 68820077 <br> E-mail: info@creativexwise.com
                    </h4>

                </div>
            </div>
            <div class="col-lg-4 col-sm-12 mt-5">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2470.032673293436!2d-0.296220684105391!3d51.75072610070356!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xfab93ccff31bb610!2zNTHCsDQ1JzAyLjYiTiAwwrAxNyczOC41Ilc!5e0!3m2!1sen!2sin!4v1671448703194!5m2!1sen!2sin"
                    width="300" height="300" style="border:0;" allowfullscreen="" loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"></iframe>

                <div>
                    <h1
                        style="font-weight:bold; font-family: 'Proxima N W01 Reg'; font-size: 30px; color: #E0266A; margin-top: 100px;">
                        New Delhi (India)
                    </h1>

                    <h2 style="font-weight:bold; font-family: 'Proxima N W01 Reg'; font-size: 20px;">
                        Creativewise Entertainment Pvt Ltd <br>
                        (Advertising, Broadcast, DI & Equipment Rental)
                    </h2>

                    <h3 style="color: black; font-family: 'Proxima N W01 Reg'; font-size: 20px;">
                        L-Ist H No 328 ST No 8 Sainik Farm Bandh Road Sangam Vihar

                        New Delhi-110080
                    </h3>

                    <h4 style="color: black; font-family: 'Proxima N W01 Reg'; font-size: 20px;">
                        Tel: 011-29914743 <br> E-mail: minfo@creativexwise.com
                    </h4>

                </div>
            </div>
        </div>

    </div>

    <div class="container">

        <div class="row">

            <h1 class="header"
                style="font-weight:bold; font-family: 'Proxima N W01 Reg'; font-size: 30px; color: #E0266A; margin-left:px; margin-right: px; margin-top: 50px;">
                Important Contacts
            </h1>


            <div class="col-6">


                <h2 style="font-weight:bold; font-family: 'Proxima N W01 Reg'; font-size: 30px; margin-top: 30px;">
                    Equipment Rental
                </h2>

                <div class="col-4">
                    <h1
                        style="font-family: 'Proxima N W01 Reg'; font-size: 20px; font-weight: 600; background-color: #E0266A; width: max-content; height: auto; color: white;">
                        Broadcast</h1>
                    <h2
                        style="font-family: 'Proxima N W01 Reg'; font-size: 20px; font-weight: 600; background-color: #E0266A; width: max-content; height: auto; color: white;">
                        Arjune Singh <br>
                        Executive Director <br>
                        Mob. +91 8828981682
                    </h2>


                </div>

            </div>

            <div class="col-6">


                <h2 style="font-weight:bold; font-family: 'Proxima N W01 Reg'; font-size: 30px; margin-top: 30px;">
                    DI & Picture Post
                </h2>

                <div class="col-2">
                    <h1
                        style="font-family: 'Proxima N W01 Reg'; font-size: 20px; font-weight: 600; background-color: #E0266A; width: max-content; height: auto; color: white;">
                        Broadcast</h1>
                    <h2
                        style="font-family: 'Proxima N W01 Reg'; font-size: 20px; font-weight: 600; background-color: #E0266A; width: max-content; height: auto; color: white;">
                        Manjit Singh <br>
                        Vice President <br>
                        Mob. +91 8745673987
                    </h2>
                </div>
            </div>

            <div>
                <h1 style="margin-top: 50px; font-family: 'Proxima N W01 Reg'; font-size: 20px; font-weight: bold;">
                    General Enquiries : T: 022-26320563
                </h1>
            </div>

        </div>
    </div>
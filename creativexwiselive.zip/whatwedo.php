<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Creative X Wise</title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200;300;400;500;600;700&display=swap"
        rel="stylesheet">
</head>

<body>
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light ">
            <a class="navbar-brand" href="/">
                <img src="/assets/images/only Logo.webp" alt="">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="/">HOME</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="whoweare.html" id="navbarScrollingDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            WHO WE ARE
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarScrollingDropdown">
                            <li><a class="dropdown-item" href="#">ABOUT US</a></li>
                            <li><a class="dropdown-item" href="#">PEOPLE</a></li>
                            <li><a class="dropdown-item" href="#">CLIENTS</a></li>
                            <li><a class="dropdown-item" href="#">AWARDS AND RECOGNITIONS</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="whatwedo.html">WHAT WE DO</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="terms&condition.html">TERMS & CONDITIONS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">CAREERS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">CONTACT US</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">CHECKOUT PAGE</a>
                    </li>

                </ul>
            </div>

        </nav>
    </div>

    <div>
        <img src="/assets/images/whatwedo.png" alt="" style="width: 1582px; height: 293px; object-fit:cover;">
    </div>

    <div>
        <h1 class="header"
            style="font-family: oswald-extralight,oswald,sans-serif; color: #D91136; margin-left: 100px; margin-right: 200px; margin-top: 50px;">
            What we do
        </h1>
    </div>

    <div class="options">
        <p style="margin-left: 90px;">Creative Services</p>
        <p>Technology Product & Services</p>
        <p>Production Services</p>
        <p>Post Production Services</p>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-3">
                <h1 style="font-family: 'Proxima N W01 Reg'; font-size: 20px; font-weight: bold; color: #D91136; margin-left: 0px;
        margin-top: 50px;">
                    Creative Services
                </h1>

                <div>
                    <img src="/assets/images/cs.png" alt="" style="margin-left: -70px">
                </div>
            </div>

            <div class="col-9" style="margin-top: 100px;">
                We are the world’s largest ‘independent’ and ‘integrated’ creative services provider. Over 1500 people
                across cities like Los Angeles, Vancouver, London, Beijing, Singapore, Mumbai, Goa, Hyderabad and
                Chandigarh deliver stunning visual effects, spectacular 3D and engaging animation addressing the needs
                of all major content markets aroud ...

                <div style="color: #D91136; font-size: 20px; font-weight: bold; margin-top: 30px;">
                    Read More >
                </div>
            </div>



        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-3">
                <h1 style="font-family: 'Proxima N W01 Reg'; font-size: 20px; font-weight: bold; color: #D91136; margin-left: 0px;
        margin-top: 50px; margin-left: -55px;">
                    Technology Product & Services
                </h1>

                <div>
                    <img src="/assets/images/Technology Product & Services.png" alt="" style="margin-left: -70px">
                </div>
            </div>

            <div class="col-9" style="margin-top: 90px;">
                Creativewise Entertainment Technologies (CWET) is the technology subsidiary of Creativewise
                Entertainment and brings together a unique blend of Media and IT skills backed by a deep understanding
                of the global media and entertainment industry. CLEAR™, our award-winning Hybrid Cloud
                technology-enabled Media ERP Suite and Cloud Media Services help broadcasters, studios, brands ...

                <div style="color: #D91136; font-size: 20px; font-weight: bold; margin-top: 20px;">
                    Read More >
                </div>
            </div>



        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-3">
                <h1 style="font-family: 'Proxima N W01 Reg'; font-size: 20px; font-weight: bold; color: #D91136; margin-left: 0px;
        margin-top: 50px; margin-left: -10px;">
                    Production Services
                </h1>

                <div>
                    <img src="/assets/images/Production Services.png" alt="" style="margin-left: -70px">
                </div>
            </div>

            <div class="col-9" style="margin-top: 100px;">
                Creativewise Entertainment is India’s largest provider of camera equipment rental services. In mid-2018
                Reliance MediaWorks (RMW) merged their Film and Media Services business with Creativewise Entertainment
                Private Limited.

                <div style="color: #D91136; font-size: 20px; font-weight: bold; margin-top: 20px;">
                    Read More >
                </div>
            </div>

        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-3">
                <h1 style="font-family: 'Proxima N W01 Reg'; font-size: 20px; font-weight: bold; color: #D91136; margin-left: 0px;
        margin-top: 50px; margin-left: -30px;">
                    Post Production Services
                </h1>

                <div>
                    <img src="/assets/images/Post Production Services.png" alt="" style="margin-left: -70px">
                </div>
            </div>

            <div class="col-9" style="margin-top: 100px;">
                Creativewise Entertainment is a global post production major with facilities in Mumbai, New York and
                London catering to local content markets. It has a highly talented team of professionals offering
                Digital Intermediate/color grading, sound and picture post.

                <div style="color: #D91136; font-size: 20px; font-weight: bold; margin-top: 20px;">
                    Read More >
                </div>
            </div>

        </div>
    </div>
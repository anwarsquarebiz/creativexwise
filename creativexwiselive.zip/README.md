# creativexwise

This is the conversion of creative x wise website from wix to coded website so that it can be used to include multiple paymentgateway.
